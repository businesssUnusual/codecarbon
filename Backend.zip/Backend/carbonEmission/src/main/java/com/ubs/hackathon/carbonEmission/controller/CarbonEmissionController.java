package com.ubs.hackathon.carbonEmission.controller;

import com.ubs.hackathon.carbonEmission.entity.UBSStream;
import com.ubs.hackathon.carbonEmission.service.CarbonEmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:8080","","null","http://10.6.112.85:8080"})
public class CarbonEmissionController {


    @Autowired
    private CarbonEmissionService carbonEmissionService;


    @GetMapping("/getCarbonEmissionForAllStream")
    public ResponseEntity<UBSStream> getCarbonEmissionForAllStream(){

        return ResponseEntity.ok(carbonEmissionService.getCarbonEmissionForAllStream());

    }

    @GetMapping("/getCarbonEmissionForAllStream1")
    public ResponseEntity<UBSStream> getCarbonEmissionForAllStream1(){

        return ResponseEntity.ok(carbonEmissionService.getCarbonEmissionForAllStream1());

    }

    @GetMapping("/getCarbonEmissionForIBMonthly")
    public ResponseEntity<UBSStream> getCarbonEmissionForIBMonthly(){

        return ResponseEntity.ok(carbonEmissionService.getCarbonEmissionForIBMonthWise());

    }

    @GetMapping("/getCarbonEmissionForAMMonthly")
    public ResponseEntity<UBSStream> getCarbonEmissionForAMMonthly(){

        return ResponseEntity.ok(carbonEmissionService.getCarbonEmissionForAMMonthly());

    }

    @GetMapping("/getCarbonEmissionForWMMonthly")
    public ResponseEntity<UBSStream> getCarbonEmissionForWMMonthly(){

        return ResponseEntity.ok(carbonEmissionService.getCarbonEmissionForWMMonthly());

    }

    @GetMapping("/getCarbonEmissionForPBMonthly")
    public ResponseEntity<UBSStream> getCarbonEmissionForPBMonthly(){

        return ResponseEntity.ok(carbonEmissionService.getCarbonEmissionForPBMonthly());

    }

    @GetMapping("/getCarbonEmissionForIBYearly")
    public ResponseEntity<UBSStream> getCarbonEmissionForIBYearly(){

        return ResponseEntity.ok(carbonEmissionService.getCarbonEmissionForIBYearly());

    }
}
