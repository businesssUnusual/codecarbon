package com.ubs.hackathon.carbonEmission.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Setter
@Getter
public class FileColumns {

    private String business_Segment;
    private String runtime_hours;
    private String power_consumption_kw;
}
