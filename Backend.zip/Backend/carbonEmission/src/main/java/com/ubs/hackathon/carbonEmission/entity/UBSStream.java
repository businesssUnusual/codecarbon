package com.ubs.hackathon.carbonEmission.entity;


import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

import java.time.Month;
import java.util.Map;

@Component
@Getter
@Setter
public class UBSStream {

   private Map<String,String> streamWiseCarbonEmission;
}
