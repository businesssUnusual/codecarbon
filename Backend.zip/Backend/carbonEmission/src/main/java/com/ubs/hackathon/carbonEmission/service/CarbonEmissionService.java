package com.ubs.hackathon.carbonEmission.service;


import com.ubs.hackathon.carbonEmission.entity.UBSStream;
import com.ubs.hackathon.carbonEmission.utilities.CalculationUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Month;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class CarbonEmissionService {

    @Autowired
    private CalculationUtility calculationUtility;

    public UBSStream getCarbonEmissionForAllStream(){
        Map<String,String> hm =  Stream.of(new Object[][] {
        { "Investment Banking", "20" },
                { "Asset Management", "30" },
                { "Wealth Management", "40" },
                { "Personal Banking", "10" },
        }).collect(Collectors.toMap(data -> (String) data[0], data -> (String) data[1]));

        UBSStream ubsStream= new UBSStream();
        ubsStream.setStreamWiseCarbonEmission(hm);
        return ubsStream;
    }

    public UBSStream getCarbonEmissionForAllStream1(){
        Map<String,Double> hm =calculationUtility.readFile("/Users/nishantkumar/Documents/Nishant/Study/Hackathon/Backend/carbonEmission/src/main/resources/static/azure_vm_carbon_emissions.csv");
        double sum=hm.values().stream().mapToDouble(Double::doubleValue).sum();

        Map<String,String> newhm =hm.entrySet().stream().collect(Collectors.toMap(
                Map.Entry::getKey,
                entry -> (String) ( String.valueOf(entry.getValue()/sum *100 ))
        ));

        UBSStream ubsStream= new UBSStream();
        ubsStream.setStreamWiseCarbonEmission(newhm);
        return ubsStream;
        
    }

    public UBSStream getCarbonEmissionForIBMonthWise(){
        Map<Integer,Double> hm =calculationUtility.readFileForMonthDate("/Users/nishantkumar/Documents/Nishant/Study/Hackathon/Backend/carbonEmission/src/main/resources/static/azure_vm_carbon_emissions.csv","Investment Banking");
      //  double sum=hm.values().stream().mapToDouble(Double::doubleValue).sum();
        String[] months = {"January", "February", "March", "April","May","June","July","August","september","October","November","December"};
         hm.entrySet().stream().forEach(System.out::println);

        // Convert the map using streams while maintaining insertion order
        Map<String, String> monthMap = hm.entrySet().stream()
                .filter(entry -> entry.getKey() < months.length)  // Ensure no out-of-bounds access
                .collect(Collectors.toMap(
                        entry -> months[entry.getKey()], // Convert integer key to corresponding month name
                       entry-> String.valueOf(entry.getValue()),              // Keep the value as it is
                        (oldValue, newValue) -> oldValue, // Merge function (not needed here, but required by toMap)
                        LinkedHashMap::new                // Maintain insertion order with LinkedHashMap
                ));

        UBSStream ubsStream= new UBSStream();
        ubsStream.setStreamWiseCarbonEmission(monthMap);
        monthMap.entrySet().stream().forEach(System.out::println);
        return ubsStream;

    }



    public UBSStream getCarbonEmissionForAMMonthly(){
        Map<Integer,Double> hm =calculationUtility.readFileForMonthDate("/Users/nishantkumar/Documents/Nishant/Study/Hackathon/Backend/carbonEmission/src/main/resources/static/azure_vm_carbon_emissions.csv","Asset Management");
        //  double sum=hm.values().stream().mapToDouble(Double::doubleValue).sum();
        String[] months = {"January", "February", "March", "April","May","June","July","August","september","October","November","December"};
        hm.entrySet().stream().forEach(System.out::println);

        // Convert the map using streams while maintaining insertion order
        Map<String, String> monthMap = hm.entrySet().stream()
                .filter(entry -> entry.getKey() < months.length)  // Ensure no out-of-bounds access
                .collect(Collectors.toMap(
                        entry -> months[entry.getKey()], // Convert integer key to corresponding month name
                        entry-> String.valueOf(entry.getValue()),              // Keep the value as it is
                        (oldValue, newValue) -> oldValue, // Merge function (not needed here, but required by toMap)
                        LinkedHashMap::new                // Maintain insertion order with LinkedHashMap
                ));

        UBSStream ubsStream= new UBSStream();
        ubsStream.setStreamWiseCarbonEmission(monthMap);
        monthMap.entrySet().stream().forEach(System.out::println);
        return ubsStream;

    }

    public UBSStream getCarbonEmissionForWMMonthly(){
        Map<Integer,Double> hm =calculationUtility.readFileForMonthDate("/Users/nishantkumar/Documents/Nishant/Study/Hackathon/Backend/carbonEmission/src/main/resources/static/azure_vm_carbon_emissions.csv","Wealth Management");
        //  double sum=hm.values().stream().mapToDouble(Double::doubleValue).sum();
        String[] months = {"January", "February", "March", "April","May","June","July","August","september","October","November","December"};
        hm.entrySet().stream().forEach(System.out::println);

        // Convert the map using streams while maintaining insertion order
        Map<String, String> monthMap = hm.entrySet().stream()
                .filter(entry -> entry.getKey() < months.length)  // Ensure no out-of-bounds access
                .collect(Collectors.toMap(
                        entry -> months[entry.getKey()], // Convert integer key to corresponding month name
                        entry-> String.valueOf(entry.getValue()),              // Keep the value as it is
                        (oldValue, newValue) -> oldValue, // Merge function (not needed here, but required by toMap)
                        LinkedHashMap::new                // Maintain insertion order with LinkedHashMap
                ));

        UBSStream ubsStream= new UBSStream();
        ubsStream.setStreamWiseCarbonEmission(monthMap);
        monthMap.entrySet().stream().forEach(System.out::println);
        return ubsStream;

    }


    public UBSStream getCarbonEmissionForPBMonthly(){
        Map<Integer,Double> hm =calculationUtility.readFileForMonthDate("/Users/nishantkumar/Documents/Nishant/Study/Hackathon/Backend/carbonEmission/src/main/resources/static/azure_vm_carbon_emissions.csv","Personal Banking");
        //  double sum=hm.values().stream().mapToDouble(Double::doubleValue).sum();
        String[] months = {"January", "February", "March", "April","May","June","July","August","september","October","November","December"};
        hm.entrySet().stream().forEach(System.out::println);

        // Convert the map using streams while maintaining insertion order
        Map<String, String> monthMap = hm.entrySet().stream()
                .filter(entry -> entry.getKey() < months.length)  // Ensure no out-of-bounds access
                .collect(Collectors.toMap(
                        entry -> months[entry.getKey()], // Convert integer key to corresponding month name
                        entry-> String.valueOf(entry.getValue()),              // Keep the value as it is
                        (oldValue, newValue) -> oldValue, // Merge function (not needed here, but required by toMap)
                        LinkedHashMap::new                // Maintain insertion order with LinkedHashMap
                ));

        UBSStream ubsStream= new UBSStream();
        ubsStream.setStreamWiseCarbonEmission(monthMap);
        monthMap.entrySet().stream().forEach(System.out::println);
        return ubsStream;

    }




    public UBSStream getCarbonEmissionForIBYearly(){
        Map<Integer,Double> hm =calculationUtility.readFileForYearDate("/Users/nishantkumar/Documents/Nishant/Study/Hackathon/Backend/carbonEmission/src/main/resources/static/azure_vm_carbon_emissions.csv","Investment Banking");
        //  double sum=hm.values().stream().mapToDouble(Double::doubleValue).sum();
        hm.entrySet().stream().forEach(System.out::println);

        Map<String,String> newhm =hm.entrySet().stream().collect(Collectors.toMap(
                entry-> String.valueOf(entry.getKey()),
                entry -> ( String.valueOf(entry.getValue()))
        ));
        UBSStream ubsStream= new UBSStream();
        ubsStream.setStreamWiseCarbonEmission(newhm);
        return ubsStream;

    }

}
