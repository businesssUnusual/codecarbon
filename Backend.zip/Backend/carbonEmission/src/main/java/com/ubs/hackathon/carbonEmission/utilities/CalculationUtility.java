package com.ubs.hackathon.carbonEmission.utilities;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.util.HashMap;
import java.util.Map;

@Component
public class CalculationUtility {

    public Map<String,Double> readFile(String path){
        Map<String,Double>    hm= new HashMap<>();
        try (FileReader reader = new FileReader(path, StandardCharsets.UTF_8);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

            for (CSVRecord csvRecord : csvParser) {
                String bs = csvRecord.get("Business Segment");
                String rh = csvRecord.get("runtime_hours");
                String pc = csvRecord.get("power_consumption_kw");

                double temp=Double.parseDouble(rh )* Double.parseDouble(pc) *0.233;
                if(hm.containsKey(bs)){
                    hm.replace(bs,hm.get(bs),Double.valueOf(hm.get(bs))+temp);
                }else{
                    hm.put(bs,temp);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return hm;
    }

    public Map<Integer,Double> readFileForMonthDate(String path,String stream){
        Map<Integer,Double>    hm= new HashMap<>();
        try (FileReader reader = new FileReader(path, StandardCharsets.UTF_8);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

            for (CSVRecord csvRecord : csvParser) {
                String bs = csvRecord.get("Business Segment");
                String rh = csvRecord.get("runtime_hours");
                String pc = csvRecord.get("power_consumption_kw");
                int month = getMonthFromDate(csvRecord.get("Date"));

                double temp=Double.parseDouble(rh )* Double.parseDouble(pc) *0.233;
                if(bs.equals(stream) && hm.containsKey(month)){
                    hm.replace(month,hm.get(month),Double.valueOf(hm.get(month))+temp);
                }else if(bs.equals(stream)){
                    hm.put(month,temp);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return hm;
    }
     public int getMonthFromDate(String date){

         LocalDate tempDate = LocalDate.parse(date);
         Month month = tempDate.getMonth();

         return month.getValue();
     }

    public int getYearFromDate(String date){

        LocalDate tempDate = LocalDate.parse(date);
        return tempDate.getYear();

    }

    public Map<Integer,Double> readFileForYearDate(String path,String stream){
        Map<Integer,Double>    hm= new HashMap<>();
        try (FileReader reader = new FileReader(path, StandardCharsets.UTF_8);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

            for (CSVRecord csvRecord : csvParser) {
                String bs = csvRecord.get("Business Segment");
                String rh = csvRecord.get("runtime_hours");
                String pc = csvRecord.get("power_consumption_kw");
                int year = getYearFromDate(csvRecord.get("Date"));

                double temp=Double.parseDouble(rh )* Double.parseDouble(pc) *0.233;
                if(bs.equals(stream) && hm.containsKey(year)){
                    hm.replace(year,hm.get(year),Double.valueOf(hm.get(year))+temp);
                }else if(bs.equals(stream)){
                    hm.put(year,temp);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return hm;
    }

}
