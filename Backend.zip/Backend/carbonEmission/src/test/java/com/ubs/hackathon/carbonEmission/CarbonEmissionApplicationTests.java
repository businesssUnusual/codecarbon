package com.ubs.hackathon.carbonEmission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarbonEmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
